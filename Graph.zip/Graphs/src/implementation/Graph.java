package implementation;

import java.util.*;

/**
 * Implements a graph. We use two maps: one map for adjacency properties 
 * (adjancencyMap) and one map (dataMap) to keep track of the data associated 
 * with a vertex. 
 * 
 * @author cmsc132
 * 
 * @param <E>
 */
public class Graph<E> {
	/* You must use the following maps in your implementation */
	private HashMap<String, HashMap<String, Integer>> adjacencyMap;
	private HashMap<String, E> dataMap;
	
	public Graph() {
		adjacencyMap = new HashMap<>();
		dataMap = new HashMap<>();
	}

	public void addVertex(String vertexName, E data) {
		if(adjacencyMap.containsKey(vertexName))
			throw new IllegalArgumentException("Name already exists");
		
		adjacencyMap.put(vertexName, new HashMap<>());
		dataMap.put(vertexName, data);
		
	}
	
	
	public void addDirectedEdge(String startVertexName, String endVertexName, int cost) {
		if(!adjacencyMap.containsKey(endVertexName) || !adjacencyMap.containsKey(startVertexName))
			throw new IllegalArgumentException("A vertext does not exist.");
		
		adjacencyMap.get(startVertexName).put(endVertexName, cost);
		
	}
	
	public String toString() {
		String[] set = selectionSort(adjacencyMap.keySet());
		String toString = "Vertices: " + arrayValues(set);
		toString += "\nEdges:\n";
		
		for(int i = 0; i < set.length; i++) {
			toString += "Vertex(" + set[i] + ")--->" + adjacencyMap.get(set[i]) 
			+ (i == set.length-1 ? "":"\n" );
		}
		
		return toString;
	}
	
	public Map<String,Integer> getAdjacentVertecies(String vertexName){
		return adjacencyMap.get(vertexName);
	}
	
	public int getCost(String startVertexName, String endVertexName) {
		if(!adjacencyMap.containsKey(endVertexName) || !adjacencyMap.containsKey(startVertexName))
			throw new IllegalArgumentException("A vertext does not exist.");
		return adjacencyMap.get(startVertexName).get(endVertexName);
		
	}
	
	public Set<String> getVertices(){
		return adjacencyMap.keySet();
	}
	
	public E getData(String vertex) {
		return dataMap.get(vertex);
	}
	
	
	public void doDepthFirstSearch(String startVertexName, CallBack<E> callback) {
		if(!adjacencyMap.containsKey(startVertexName))
			throw new IllegalArgumentException("A vertext does not exist.");
		
		
		Stack<String> discovered = new Stack<>();
		Stack<String> visited = new Stack<>();
		
		discovered.push(startVertexName);
		
		while(!discovered.empty()) {
			String s = discovered.pop();
			if(!visited.contains(s)) {
				visited.push(s);
				callback.processVertex(s, dataMap.get(s));
				for(String y : adjacencyMap.get(s).keySet()
						.toArray(new String[adjacencyMap.get(s).size()])) {
					if(!visited.contains(y)) {
						discovered.push(y);
						
					}
				}
			}
		}
		
		//dfsHelp(startVertexName, callback, visited);
		
	}
	
	
	public void doBreadthFirstSearch(String startVertexName, CallBack<E> callback) {
		if(!adjacencyMap.containsKey(startVertexName))
			throw new IllegalArgumentException("A vertext does not exist.");
		
		HashSet<String> unvisit = new HashSet<>();
		ArrayList<String> visited = new ArrayList();
		addConnectedVertexes(startVertexName, unvisit, visited);
		
		
		callback.processVertex(startVertexName, dataMap.get(startVertexName));
		unvisit.remove(startVertexName);
		bfsHelp(startVertexName, callback, 0, unvisit, 0);
	}
	private void bfsHelp(String curr, CallBack<E> callback, int radius, HashSet<String> unvisit, int limit) {
		if(unvisit.isEmpty()) return;
		
		
		if(radius == limit) {
		for(String s : adjacencyMap.get(curr).keySet()
				.toArray(new String[adjacencyMap.get(curr).size()])) {
			if(unvisit.contains(s)) {
			callback.processVertex(s, dataMap.get(s));
			unvisit.remove(s);
			if(unvisit.isEmpty()) return;
			}
		}
		} else {
			for(String s : adjacencyMap.get(curr).keySet()
					.toArray(new String[adjacencyMap.get(curr).size()])) {
				bfsHelp(s, callback, radius + 1, unvisit, limit);
				if(unvisit.isEmpty()) return;
			}
		}
		while((!unvisit.isEmpty())&& radius == 0) {
			bfsHelp(curr, callback, 0, unvisit, limit+1);
			if(unvisit.isEmpty()) return;
		
		}
	}
	private void addConnectedVertexes(String s, HashSet<String> set, ArrayList<String> visited) {
		if(visited.contains(s)) return;
		set.add(s);
		visited.add(s);
		for(String next : adjacencyMap.get(s).keySet().toArray(new String[adjacencyMap.get(s).size()])){
			addConnectedVertexes(next, set, visited);
		}
	}
	
	public int doDijkstras(String startVertexName, String endVertexName, ArrayList<String> shortestPath) {
		if(!adjacencyMap.containsKey(endVertexName) || !adjacencyMap.containsKey(startVertexName))
			throw new IllegalArgumentException("A vertext does not exist.");
		
		String[] p = new String[dataMap.size()];
		int[] c = new int[dataMap.size()];
		
		String[] Vertexes = selectionSort(dataMap.keySet());
		HashMap<String, Integer> indexFor = new HashMap<>();
		
		for(int i = 0; i < Vertexes.length; i++) {
			indexFor.put(Vertexes[i], i);
		}
		
		Stack<String> seen = new Stack<>();
		int start = indexFor.get(startVertexName);
		
		Arrays.fill(p, "None");
		Arrays.fill(c, -1);
		c[start] = 0;
		p[start] = "-";
		
		String curr =  startVertexName;
		while(true) {
			if(!seen.contains(curr)) {
				seen.push(curr);
				for(String s : adjacencyMap.get(Vertexes[indexFor.get(curr)]).keySet()
						.toArray(new String[adjacencyMap.get(Vertexes[indexFor.get(curr)]).size()])){
					if(c[indexFor.get(curr)] + adjacencyMap.get(curr).get(s) < c[indexFor.get(s)] || c[indexFor.get(s)] == -1) {
						
						 c[indexFor.get(s)] = c[indexFor.get(curr)] + adjacencyMap.get(curr).get(s);
						 p[indexFor.get(s)] = curr;
					}
				}
			}else break;
			int least = getLeastIndex(c, seen, Vertexes);
			curr = Vertexes[least == 9999 ? start : least ];
			
		}
		int cost = c[indexFor.get(endVertexName)];
		for(String pre = endVertexName; (!pre.equals("None") && (!pre.equals("-")) ); pre = p[indexFor.get(pre)]) {
			shortestPath.add(pre);
			//cost += c[indexFor.get(pre)];
		}
		
		ArrayList<String> reverse = new ArrayList<>();
		for(int i = shortestPath.size()-1; i >=0; i--) {
			reverse.add(shortestPath.get(i));
		}
		for(; !shortestPath.isEmpty();) {
			shortestPath.remove(0);
		}
		for(int i = 0; i < reverse.size(); i++) {
			shortestPath.add(reverse.get(i));
		}
		if(cost == -1) {
			shortestPath.remove(0);
			shortestPath.add("None");
		}
		return cost;
	}
	
	
	
	private static String arrayValues (String[] array) {
		String toString = "[";
		for(int i = 0; i < array.length; i++) {
			toString += array[i];
			if(i != array.length - 1) toString  += ", ";
		}
		return toString + "]";
	}
	
	private static String[] selectionSort(Set<String> list) {
		String[] set =  list.toArray(new String[list.size()]);

		for(int i = 0; i < set.length; i++) {
			for(int j = i + 1; j < set.length; j++ ) {
				if(set[j].compareTo(set[i]) < 0) {
					String stringJ = set[j];
					String stringI = set[i];
					set[j] = stringI;
					set[i] = stringJ;
					break;
				}
			}
		}
		return set;
		
	}
	
	private static int[] selectionSortInt(int[] list) {
		int[] set =  list.clone();
		
		for(int i = 0; i < set.length; i++) {
			for(int j = i + 1; j < set.length; j++ ) {
				if(set[j] < (set[i])) {
					int stringJ = set[j];
					int stringI = set[i];
					set[j] = stringI;
					set[i] = stringJ;
					break;
				}
			}
		}
		return set;
		
	}


	
	private static int getLeastIndex(int[] arr, Collection<String> seen, String[] Vertexes) {
		int least = 9999;
		int index = 9999;
		
		for(int i = 0; i < arr.length; i++) {
			if(seen.contains(Vertexes[i])) continue;
			if(arr[i] == -1) continue;
			if(least > arr[i]) {
				least = arr[i];
				index = i;
			}
		}
		
		return index;
	}


}

	




